# Option Stock Selector - Android Build

This repository contains the Flutter application source.

## Phone-only build

GitHub Actions can generate the Android APK without a laptop.

The workflow:
1. Extracts the uploaded Flutter ZIP.
2. Generates the native Android project with `flutter create`.
3. Adds Internet permission.
4. Installs Flutter dependencies.
5. Runs analyzer and tests.
6. Builds `app-release.apk`.
7. Uploads the APK as a GitHub Actions artifact.

Run it from:
GitHub → Actions → Build Android APK → Run workflow.

The generated artifact is named `option-stock-selector-apk`.
