# Option Stock Selector

Flutter Android app for intraday option-stock signal ranking.

Current architecture:
- Yahoo Finance data service placeholder
- Local SQLite storage
- 5-minute candle model
- EMA 9/21, RSI, VWAP, RVOL
- Momentum and breakout
- 100-point scoring
- CALL / PUT ranking
- Dashboard and stock detail screens

Important: Yahoo Finance endpoints are not an official guaranteed trading-data API. Validate data and backtest before using real money.
