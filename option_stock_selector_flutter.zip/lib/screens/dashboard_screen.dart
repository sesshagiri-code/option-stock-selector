import 'dart:async';
import 'package:flutter/material.dart';
import '../models/signal.dart';
import '../services/scanner_service.dart';
import '../utils/market_time.dart';
import '../widgets/signal_card.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final scanner = ScannerService();
  List<Signal> signals = [];
  bool loading = false;
  String filter = 'ALL';
  Timer? timer;

  @override
  void initState() {
    super.initState();
    loadSignals();
    timer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (MarketTime.isScanTime()) loadSignals();
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> loadSignals() async {
    if (loading) return;
    setState(() => loading = true);
    try {
      final result = await scanner.scanMarket();
      if (mounted) setState(() => signals = result);
    } catch (e) {
      debugPrint('Scanner error: $e');
    }
    if (mounted) setState(() => loading = false);
  }

  List<Signal> get filtered {
    if (filter == 'CALL') return signals.where((s) => s.direction == 'CALL').toList();
    if (filter == 'PUT') return signals.where((s) => s.direction == 'PUT').toList();
    return signals;
  }

  @override
  Widget build(BuildContext context) {
    final open = MarketTime.isMarketOpen();
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Option Stock Selector', style: TextStyle(fontWeight: FontWeight.bold)),
            Text('Intraday Scanner', style: TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
        actions: [
          IconButton(
            onPressed: loading ? null : loadSignals,
            icon: loading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: loadSignals,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _marketStatus(open),
            const SizedBox(height: 16),
            _summary(),
            const SizedBox(height: 20),
            _tabs(),
            const SizedBox(height: 16),
            if (loading && signals.isEmpty)
              const Center(child: Padding(padding: EdgeInsets.all(40), child: CircularProgressIndicator())),
            if (!loading && filtered.isEmpty)
              const Center(child: Padding(
                padding: EdgeInsets.all(50),
                child: Text('No qualifying signals'),
              )),
            ...filtered.map((s) => SignalCard(signal: s)),
          ],
        ),
      ),
    );
  }

  Widget _marketStatus(bool open) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: open ? const Color(0xFF0D2A22) : const Color(0xFF211A1A),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Row(
      children: [
        Container(width: 10, height: 10, decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: open ? const Color(0xFF00C896) : Colors.red,
        )),
        const SizedBox(width: 10),
        Text(open ? 'MARKET OPEN' : 'MARKET CLOSED',
          style: TextStyle(fontWeight: FontWeight.bold, color: open ? const Color(0xFF00C896) : Colors.red)),
        const Spacer(),
        const Text('NSE', style: TextStyle(color: Colors.grey)),
      ],
    ),
  );

  Widget _summary() {
    final calls = signals.where((s) => s.direction == 'CALL').length;
    final puts = signals.where((s) => s.direction == 'PUT').length;
    return Row(children: [
      _summaryCard('SIGNALS', signals.length),
      const SizedBox(width: 8),
      _summaryCard('CALL', calls),
      const SizedBox(width: 8),
      _summaryCard('PUT', puts),
    ]);
  }

  Widget _summaryCard(String title, int value) => Expanded(
    child: Card(child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('$value', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(fontSize: 11, color: Colors.grey)),
      ]),
    )),
  );

  Widget _tabs() => Row(children: [
    _tab('ALL'), const SizedBox(width: 8), _tab('CALL'), const SizedBox(width: 8), _tab('PUT'),
  ]);

  Widget _tab(String value) => Expanded(
    child: GestureDetector(
      onTap: () => setState(() => filter = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: filter == value ? const Color(0xFF00C896) : const Color(0xFF111923),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(child: Text(value, style: TextStyle(
          fontWeight: FontWeight.bold,
          color: filter == value ? Colors.black : Colors.white,
        ))),
      ),
    ),
  );
}
