import 'package:flutter/material.dart';
import '../models/signal.dart';

class StockDetailScreen extends StatelessWidget {
  final Signal signal;
  const StockDetailScreen({super.key, required this.signal});

  @override
  Widget build(BuildContext context) {
    final color = signal.direction == 'CALL' ? const Color(0xFF00C896) : const Color(0xFFFF4D67);
    return Scaffold(
      appBar: AppBar(title: Text(signal.symbol.replaceAll('.NS', ''))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(child: Text(signal.direction, style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: color))),
          Center(child: Text(signal.trend, style: TextStyle(color: color))),
          const SizedBox(height: 20),
          Card(child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              const Text('TOTAL SCORE', style: TextStyle(color: Colors.grey)),
              Text(signal.score.toInt().toString(), style: TextStyle(fontSize: 52, fontWeight: FontWeight.bold, color: color)),
              const Text('/ 100', style: TextStyle(color: Colors.grey)),
            ]),
          )),
          const SizedBox(height: 20),
          const Text('Indicators', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          _indicator('Price', '₹${signal.price.toStringAsFixed(2)}'),
          _indicator('RSI', signal.rsi.toStringAsFixed(2)),
          _indicator('RVOL', signal.rvol.toStringAsFixed(2)),
          _indicator('VWAP', signal.vwap.toStringAsFixed(2)),
          _indicator('EMA 9', signal.ema9.toStringAsFixed(2)),
          _indicator('EMA 21', signal.ema21.toStringAsFixed(2)),
          const SizedBox(height: 20),
          const Text('Score Breakdown', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          _score('Trend', signal.trendScore),
          _score('RSI', signal.rsiScore),
          _score('VWAP', signal.vwapScore),
          _score('Volume / RVOL', signal.volumeScore),
          _score('Momentum', signal.momentumScore),
          _score('Breakout', signal.breakoutScore),
          _score('Price Action', signal.priceActionScore),
          _score('Volume Confirmation', signal.volumeConfirmationScore),
        ],
      ),
    );
  }

  Widget _indicator(String title, String value) => Card(
    margin: const EdgeInsets.only(top: 8),
    child: ListTile(title: Text(title), trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.bold))),
  );

  Widget _score(String title, double value) => Card(
    margin: const EdgeInsets.only(top: 8),
    child: ListTile(
      title: Text(title),
      trailing: Text('${value.toInt()}'),
    ),
  );
}
