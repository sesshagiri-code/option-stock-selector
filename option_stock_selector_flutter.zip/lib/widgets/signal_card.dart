import 'package:flutter/material.dart';
import '../models/signal.dart';
import '../screens/stock_detail_screen.dart';

class SignalCard extends StatelessWidget {
  final Signal signal;
  const SignalCard({super.key, required this.signal});

  @override
  Widget build(BuildContext context) {
    final isCall = signal.direction == 'CALL';
    final color = isCall ? const Color(0xFF00C896) : const Color(0xFFFF4D67);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => StockDetailScreen(signal: signal)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          signal.symbol.replaceAll('.NS', ''),
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(signal.trend, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                  _score(signal.score, color),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  _metric('PRICE', '₹${signal.price.toStringAsFixed(2)}'),
                  _metric('RSI', signal.rsi.toStringAsFixed(1)),
                  _metric('RVOL', signal.rvol.toStringAsFixed(2)),
                  _metric('VWAP', signal.vwap.toStringAsFixed(1)),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: color.withOpacity(.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(signal.direction, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _score(double score, Color color) => Container(
    width: 62,
    height: 62,
    decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 4)),
    child: Center(
      child: Text(score.toInt().toString(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    ),
  );

  Widget _metric(String title, String value) => Expanded(
    child: Column(
      children: [
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 3),
        Text(title, style: const TextStyle(fontSize: 9, color: Colors.grey)),
      ],
    ),
  );
}
