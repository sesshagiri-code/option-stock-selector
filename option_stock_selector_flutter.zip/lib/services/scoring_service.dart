import '../models/candle.dart';
import 'indicator_service.dart';

class ScoringResult {
  final double score, rsi, rvol, vwap, ema9, ema21, momentum;
  final String direction, trend;
  final double trendScore, rsiScore, vwapScore, volumeScore;
  final double momentumScore, breakoutScore, priceActionScore, volumeConfirmationScore;

  const ScoringResult({
    required this.score,
    required this.direction,
    required this.trend,
    required this.rsi,
    required this.rvol,
    required this.vwap,
    required this.ema9,
    required this.ema21,
    required this.momentum,
    required this.trendScore,
    required this.rsiScore,
    required this.vwapScore,
    required this.volumeScore,
    required this.momentumScore,
    required this.breakoutScore,
    required this.priceActionScore,
    required this.volumeConfirmationScore,
  });
}

class ScoringService {
  final IndicatorService indicators = IndicatorService();

  ScoringResult calculate(List<Candle> candles) {
    if (candles.length < 30) throw Exception('At least 30 candles required');

    final closes = candles.map((e) => e.close).toList();
    final current = candles.last;
    final price = current.close;
    final ema9 = indicators.ema(closes, 9);
    final ema21 = indicators.ema(closes, 21);
    final rsi = indicators.rsi(closes);
    final vwap = indicators.vwap(candles);
    final rvol = indicators.rvol(candles);
    final momentum = indicators.momentum(closes);

    final bullish = ema9 > ema21 && price > ema9;
    final bearish = ema9 < ema21 && price < ema9;
    final trend = bullish ? 'BULLISH' : bearish ? 'BEARISH' : 'SIDEWAYS';
    final direction = bullish ? 'CALL' : bearish ? 'PUT' : 'WAIT';

    double trendScore = (bullish || bearish) ? 20 : 0;
    double rsiScore = 0;
    if (bullish) {
      if (rsi >= 55 && rsi <= 70) rsiScore = 10;
      else if (rsi >= 50 && rsi < 55) rsiScore = 5;
    } else if (bearish) {
      if (rsi >= 30 && rsi <= 45) rsiScore = 10;
      else if (rsi > 45 && rsi <= 50) rsiScore = 5;
    }

    final vwapScore = (bullish && price > vwap) || (bearish && price < vwap) ? 10.0 : 0.0;

    double volumeScore = 0;
    if (rvol >= 2.0) volumeScore = 15;
    else if (rvol >= 1.5) volumeScore = 12;
    else if (rvol >= 1.2) volumeScore = 7;

    double momentumScore = 0;
    if (bullish) {
      if (momentum >= 1) momentumScore = 15;
      else if (momentum >= .5) momentumScore = 10;
      else if (momentum > 0) momentumScore = 5;
    } else if (bearish) {
      if (momentum <= -1) momentumScore = 15;
      else if (momentum <= -.5) momentumScore = 10;
      else if (momentum < 0) momentumScore = 5;
    }

    final breakout = bullish && indicators.bullishBreakout(candles) ||
        bearish && indicators.bearishBreakdown(candles);
    final breakoutScore = breakout ? 10.0 : 0.0;

    final range = current.high - current.low;
    final body = (current.close - current.open).abs();
    double priceActionScore = 0;
    if (range > 0) {
      final ratio = body / range;
      if (ratio >= .6 &&
          ((bullish && current.close > current.open) ||
           (bearish && current.close < current.open))) {
        priceActionScore = 10;
      } else if (ratio >= .4) {
        priceActionScore = 5;
      }
    }

    final volumeConfirmationScore =
        rvol >= 1.5 &&
        ((bullish && current.close > current.open) ||
         (bearish && current.close < current.open))
            ? 10.0
            : rvol >= 1.2 ? 5.0 : 0.0;

    final total = trendScore + rsiScore + vwapScore + volumeScore +
        momentumScore + breakoutScore + priceActionScore + volumeConfirmationScore;

    return ScoringResult(
      score: total,
      direction: direction,
      trend: trend,
      rsi: rsi,
      rvol: rvol,
      vwap: vwap,
      ema9: ema9,
      ema21: ema21,
      momentum: momentum,
      trendScore: trendScore,
      rsiScore: rsiScore,
      vwapScore: vwapScore,
      volumeScore: volumeScore,
      momentumScore: momentumScore,
      breakoutScore: breakoutScore,
      priceActionScore: priceActionScore,
      volumeConfirmationScore: volumeConfirmationScore,
    );
  }
}
