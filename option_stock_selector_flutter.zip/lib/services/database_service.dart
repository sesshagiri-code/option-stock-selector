import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  DatabaseService._();
  static final instance = DatabaseService._();
  Database? _db;

  Future<Database> get database async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'option_stock_selector.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            price REAL NOT NULL,
            direction TEXT NOT NULL,
            trend TEXT NOT NULL,
            score REAL NOT NULL,
            rsi REAL,
            rvol REAL,
            vwap REAL,
            ema9 REAL,
            ema21 REAL,
            momentum REAL,
            trend_score REAL,
            rsi_score REAL,
            vwap_score REAL,
            volume_score REAL,
            momentum_score REAL,
            breakout_score REAL,
            price_action_score REAL,
            volume_confirmation_score REAL,
            created_at INTEGER NOT NULL
          )
        ''');
      },
    );
  }

  Future<void> saveSignal(Map<String, dynamic> signal) async {
    final db = await database;
    await db.insert('signals', signal);
  }

  Future<List<Map<String, dynamic>>> getTopSignals({int limit = 10}) async {
    final db = await database;
    return db.query('signals', orderBy: 'score DESC', limit: limit);
  }
}
