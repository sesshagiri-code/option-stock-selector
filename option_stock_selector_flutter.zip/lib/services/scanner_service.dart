import '../data/stock_universe.dart';
import '../models/signal.dart';
import 'database_service.dart';
import 'scoring_service.dart';
import 'yahoo_finance_service.dart';

class ScannerService {
  final yahoo = YahooFinanceService();
  final database = DatabaseService.instance;
  final scoring = ScoringService();

  Future<List<Signal>> scanMarket() async {
    final signals = <Signal>[];

    for (final symbol in StockUniverse.symbols) {
      try {
        final candles = await yahoo.downloadCandles(symbol);
        if (candles.length < 30) continue;

        final result = scoring.calculate(candles);
        if (result.direction == 'WAIT' || result.score < 70 || result.rvol < 1.2) {
          continue;
        }

        final signal = Signal(
          symbol: symbol,
          price: candles.last.close,
          direction: result.direction,
          trend: result.trend,
          score: result.score,
          rsi: result.rsi,
          rvol: result.rvol,
          vwap: result.vwap,
          ema9: result.ema9,
          ema21: result.ema21,
          momentum: result.momentum,
          trendScore: result.trendScore,
          rsiScore: result.rsiScore,
          vwapScore: result.vwapScore,
          volumeScore: result.volumeScore,
          momentumScore: result.momentumScore,
          breakoutScore: result.breakoutScore,
          priceActionScore: result.priceActionScore,
          volumeConfirmationScore: result.volumeConfirmationScore,
          createdAt: DateTime.now(),
        );

        signals.add(signal);
        await database.saveSignal(signal.toMap());

        await Future.delayed(const Duration(milliseconds: 250));
      } catch (_) {
        // Continue scanning other symbols.
      }
    }

    signals.sort((a, b) => b.score.compareTo(a.score));
    return signals.take(10).toList();
  }
}
