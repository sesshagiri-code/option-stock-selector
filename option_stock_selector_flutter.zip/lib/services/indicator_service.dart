import '../models/candle.dart';

class IndicatorService {
  double ema(List<double> values, int period) {
    if (values.isEmpty) return 0;
    if (values.length < period) return values.last;
    final multiplier = 2 / (period + 1);
    double value = values.take(period).reduce((a, b) => a + b) / period;
    for (int i = period; i < values.length; i++) {
      value = ((values[i] - value) * multiplier) + value;
    }
    return value;
  }

  double rsi(List<double> closes, {int period = 14}) {
    if (closes.length <= period) return 50;
    double gains = 0, losses = 0;
    final start = closes.length - period;
    for (int i = start; i < closes.length; i++) {
      final change = closes[i] - closes[i - 1];
      if (change > 0) {
        gains += change;
      } else {
        losses += change.abs();
      }
    }
    if (losses == 0) return 100;
    final rs = (gains / period) / (losses / period);
    return 100 - (100 / (1 + rs));
  }

  double vwap(List<Candle> candles) {
    double pv = 0, volume = 0;
    for (final c in candles) {
      final typical = (c.high + c.low + c.close) / 3;
      pv += typical * c.volume;
      volume += c.volume;
    }
    return volume == 0 ? candles.last.close : pv / volume;
  }

  double rvol(List<Candle> candles, {int period = 20}) {
    if (candles.length <= period) return 1;
    final current = candles.last.volume;
    final start = candles.length - period - 1;
    final previous = candles.sublist(start, candles.length - 1);
    final average = previous.map((e) => e.volume).reduce((a, b) => a + b) / previous.length;
    return average == 0 ? 1 : current / average;
  }

  double momentum(List<double> closes, {int lookback = 5}) {
    if (closes.length <= lookback) return 0;
    final previous = closes[closes.length - 1 - lookback];
    return previous == 0 ? 0 : ((closes.last - previous) / previous) * 100;
  }

  bool bullishBreakout(List<Candle> candles, {int lookback = 20}) {
    if (candles.length <= lookback) return false;
    final previous = candles.sublist(candles.length - lookback - 1, candles.length - 1);
    final highest = previous.map((e) => e.high).reduce((a, b) => a > b ? a : b);
    return candles.last.close > highest;
  }

  bool bearishBreakdown(List<Candle> candles, {int lookback = 20}) {
    if (candles.length <= lookback) return false;
    final previous = candles.sublist(candles.length - lookback - 1, candles.length - 1);
    final lowest = previous.map((e) => e.low).reduce((a, b) => a < b ? a : b);
    return candles.last.close < lowest;
  }
}
