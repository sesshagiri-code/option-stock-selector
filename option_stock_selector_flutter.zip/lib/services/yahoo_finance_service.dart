import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/candle.dart';

class YahooFinanceService {
  Future<List<Candle>> downloadCandles(
    String symbol, {
    String interval = '5m',
    String range = '5d',
  }) async {
    final url = Uri.parse(
      'https://query1.finance.yahoo.com/v8/finance/chart/$symbol'
      '?range=$range&interval=$interval&includePrePost=false',
    );

    final response = await http.get(
      url,
      headers: {'User-Agent': 'Mozilla/5.0'},
    );

    if (response.statusCode != 200) {
      throw Exception('Yahoo Finance HTTP ${response.statusCode}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final result = data['chart']['result'];
    if (result == null || result.isEmpty) {
      throw Exception('No Yahoo Finance data for $symbol');
    }

    final first = result[0] as Map<String, dynamic>;
    final timestamps = (first['timestamp'] as List?) ?? [];
    final quote = first['indicators']['quote'][0] as Map<String, dynamic>;

    final opens = quote['open'] as List?;
    final highs = quote['high'] as List?;
    final lows = quote['low'] as List?;
    final closes = quote['close'] as List?;
    final volumes = quote['volume'] as List?;

    final candles = <Candle>[];

    for (int i = 0; i < timestamps.length; i++) {
      final o = opens?[i];
      final h = highs?[i];
      final l = lows?[i];
      final c = closes?[i];
      final v = volumes?[i];

      if (o == null || h == null || l == null || c == null) continue;

      candles.add(Candle(
        time: DateTime.fromMillisecondsSinceEpoch(
          (timestamps[i] as num).toInt() * 1000,
          isUtc: true,
        ).toLocal(),
        open: (o as num).toDouble(),
        high: (h as num).toDouble(),
        low: (l as num).toDouble(),
        close: (c as num).toDouble(),
        volume: (v as num?)?.toDouble() ?? 0,
      ));
    }

    return candles;
  }
}
