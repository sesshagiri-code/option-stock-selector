class Signal {
  final String symbol;
  final double price;
  final String direction;
  final String trend;
  final double score;
  final double rsi;
  final double rvol;
  final double vwap;
  final double ema9;
  final double ema21;
  final double momentum;
  final double trendScore;
  final double rsiScore;
  final double vwapScore;
  final double volumeScore;
  final double momentumScore;
  final double breakoutScore;
  final double priceActionScore;
  final double volumeConfirmationScore;
  final DateTime createdAt;

  const Signal({
    required this.symbol,
    required this.price,
    required this.direction,
    required this.trend,
    required this.score,
    required this.rsi,
    required this.rvol,
    required this.vwap,
    required this.ema9,
    required this.ema21,
    required this.momentum,
    required this.trendScore,
    required this.rsiScore,
    required this.vwapScore,
    required this.volumeScore,
    required this.momentumScore,
    required this.breakoutScore,
    required this.priceActionScore,
    required this.volumeConfirmationScore,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
    'symbol': symbol,
    'price': price,
    'direction': direction,
    'trend': trend,
    'score': score,
    'rsi': rsi,
    'rvol': rvol,
    'vwap': vwap,
    'ema9': ema9,
    'ema21': ema21,
    'momentum': momentum,
    'trend_score': trendScore,
    'rsi_score': rsiScore,
    'vwap_score': vwapScore,
    'volume_score': volumeScore,
    'momentum_score': momentumScore,
    'breakout_score': breakoutScore,
    'price_action_score': priceActionScore,
    'volume_confirmation_score': volumeConfirmationScore,
    'created_at': createdAt.millisecondsSinceEpoch,
  };
}
