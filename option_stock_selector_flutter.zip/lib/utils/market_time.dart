class MarketTime {
  static bool isMarketOpen([DateTime? input]) {
    final now = input ?? DateTime.now();
    final start = DateTime(now.year, now.month, now.day, 9, 15);
    final end = DateTime(now.year, now.month, now.day, 15, 15);
    return !now.isBefore(start) && !now.isAfter(end);
  }

  static bool isScanTime([DateTime? input]) {
    final now = input ?? DateTime.now();
    if (!isMarketOpen(now)) return false;
    final minutes = now.hour * 60 + now.minute;
    final start = 9 * 60 + 15;
    return (minutes - start) % 5 == 0;
  }
}
