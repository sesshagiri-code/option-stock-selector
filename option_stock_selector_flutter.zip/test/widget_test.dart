import 'package:flutter_test/flutter_test.dart';
import 'package:option_stock_selector/main.dart';

void main() {
  testWidgets('app starts', (tester) async {
    await tester.pumpWidget(const OptionStockApp());
    expect(find.text('Option Stock Selector'), findsOneWidget);
  });
}
